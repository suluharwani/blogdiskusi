/*
Name: 			Construction
Written by: 	Okler Themes - (http://www.okler.net)
Theme Version:	3.1.0
*/

(function( $ ) {

	'use strict';

}).apply( this, [ jQuery ]);